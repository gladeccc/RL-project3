import os

_curr_directory = os.path.dirname(os.path.abspath(__file__))
