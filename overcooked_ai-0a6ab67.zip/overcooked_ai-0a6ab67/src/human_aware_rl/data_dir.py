import os

DATA_DIR = os.path.abspath(".")
